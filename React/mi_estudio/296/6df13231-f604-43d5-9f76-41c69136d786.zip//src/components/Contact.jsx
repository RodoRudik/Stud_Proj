const contacts = [
  {
    name: "Jackie Chan",
    imgURL:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3_CUGAxYDi_Z2SSbih68aMfiHVPQH_Y2pKLgTPOjK3Q&s=10",
    phone: "984794750230",
    email: "jack@chan.ch",
  },
  {
    name: "Tony Jaa",
    imgURL:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWz0pYMUXOz9Tu8dM0r7w16pyCcC4CtYyH5lclZT_mRw&s=10",
    phone: "7484753207024",
    email: "ton@jaa.ta",
  },
  {
    name: "Bruce Lee",
    imgURL:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzoDUzjM2M8YmayoYamA4KSu5Fgk6Cmjs5-oK6oVVChA&s",
    phone: "093249713946",
    email: "bruce@lee.us",
  },
];

export default contacts;
